sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("mailsend.controller.mailsend",{onInit:function(){}})});
//# sourceMappingURL=mailsend.controller.js.map