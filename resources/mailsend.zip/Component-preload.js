//@ui5-bundle mailsend/Component-preload.js
sap.ui.require.preload({
	"mailsend/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","mailsend/model/models"],function(e,i,t){"use strict";return e.extend("mailsend.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(t.createDeviceModel(),"device")}})});
},
	"mailsend/controller/App.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("mailsend.controller.App",{onInit:function(){}})});
},
	"mailsend/controller/mailsend.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("mailsend.controller.mailsend",{onInit:function(){}})});
},
	"mailsend/i18n/i18n.properties":'# This is the resource bundle for mailsend\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=App Title\n\n#YDES: Application description\nappDescription=An SAP Fiori application.\n#XTIT: Main view title\ntitle=App Title',
	"mailsend/manifest.json":'{"_version":"1.59.0","sap.app":{"id":"mailsend","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.13.6","toolsId":"b1e4446f-f080-4581-96fc-7cd0bb70ad85"},"dataSources":{"mainService":{"uri":"odata/v4/api/","type":"OData","settings":{"annotations":[],"odataVersion":"4.0"}}}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.124.1","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"mailsend.i18n.i18n"}},"":{"dataSource":"mainService","preload":true,"settings":{"operationMode":"Server","autoExpandSelect":true,"earlyRequests":true}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"mailsend.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"Routemailsend","pattern":":?query:","target":["Targetmailsend"]}],"targets":{"Targetmailsend":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"mailsend","viewName":"mailsend"}}},"rootView":{"viewName":"mailsend.view.App","type":"XML","async":true,"id":"App"}},"sap.cloud":{"public":true,"service":"ui_mail"}}',
	"mailsend/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"mailsend/view/App.view.xml":'<mvc:View controllerName="mailsend.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"mailsend/view/mailsend.view.xml":'<mvc:View controllerName="mailsend.controller.mailsend"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><content /></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
